---
layout: wiki
title: 体系结构
cate1: Android
cate2: 
description: 体系结构
keywords: Android
---

## 架构图

![Android stack](/images/wiki/android-stack.png)

## 参考

* [The Android Source Code](http://source.android.com/source/index.html)
