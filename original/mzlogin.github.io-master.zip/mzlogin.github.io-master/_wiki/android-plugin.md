---
layout: wiki
title: 插件化
cate1: Android
cate2:
description: 插件化
keywords: Android
---

## 方案

* [DroidPlugin](https://github.com/DroidPluginTeam/DroidPlugin)

    项目里的学习资料写得很好。

* [Small](https://github.com/wequick/Small)

* [dynamic-load-apk](https://github.com/singwhatiwanna/dynamic-load-apk)

## 参考

* [Android 开发中的日常积累](https://github.com/lizhangqu/CoreLink#android插件化开发与动态加载)
