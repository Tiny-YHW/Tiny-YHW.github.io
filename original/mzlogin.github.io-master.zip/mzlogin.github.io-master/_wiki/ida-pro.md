---
layout: wiki
title: IDA Pro
cate1: Tools
cate2: Debug
description: 静态分析神器
keywords: debug, IDA Pro
---

### 快捷键

C --> Ctrl

S --> Shift

M --> Alt

Cmd --> Command

| 功能           | 快捷键  |
|----------------|---------|
| 搜索文本       | M-t     |
| 返回上一个位置 | Esc     |
| 前进到下一位置 | C-Enter |
| 显示伪 C 代码  | F5      |
| 跳转到地址     | g       |
