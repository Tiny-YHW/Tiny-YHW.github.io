---
layout: fragment
title: Kindle 字典安装
tags: [kindle]
description: Kindle 字典安装
keywords: Kindle, 字典
---

**Kindle 字典**

mobi 格式，拷贝到 /mnt/us/documents/dictionaries 里，设置-语言和字典-字典，选择默认

参考 <https://bookfere.com/dict#KDict4>

**KOReader 字典**

目前只支持 Stardict 格式的字典。

解压后将 .idx、.ifo、.dict 拷贝到 /mnt/us/koreader/data/dict 目录里。

如果解压后是 .idx、.ifo、.dz，则先将 .dz 解压出 .dict（可改后缀名为 .gz 再解压）。

参考 <https://zhuanlan.zhihu.com/p/47032711>
