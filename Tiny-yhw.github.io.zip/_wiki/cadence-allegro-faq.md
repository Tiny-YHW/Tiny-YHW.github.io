---
layout: wiki
title: 常见问题FAQ
cate1: Cadence Allegro
cate2: 
keywords: 
---

Frequently asked question

* * *

## 其他


* [Allegro文件不能打开或打开为空白的问题及解决方案](https://tiny-yhw.github.io//allegro-cant-open){:target="_blank"}
