---
layout: post
title: Allegro Label Tune 位号自适应大小并居中
categories: Allegro
description: 
date: 2023-06-15
---

Label Tune是一个Productivity Toolbox工具，再16.6某补丁及之后版本可用，并需要启用Productivity Toolbox选项，如果设置了默认打开方式则可以从File-Change Editor处更换

![](http://a1024.synology.me:222/images/blog2022/toolbox.jpg)

从启动命令Manufacturer-Label Tune

具体我也不详细介绍了，详见下面动图

动图演示
----

![](http://a1024.synology.me:222/images/blog2022/LabelTune%20.gif)

视频介绍
----

下面附一个演示视频及使用说明文档（英文的）

<iframe width="720" height="405" frameborder="0" src="https://v.qq.com/txp/iframe/player.html?vid=m0362j89qkl" allowFullScreen="true"></iframe>


官方文档
----

链接:[https://pan.baidu.com/s/1bo9qYK3](https://pan.baidu.com/s/1bo9qYK3)