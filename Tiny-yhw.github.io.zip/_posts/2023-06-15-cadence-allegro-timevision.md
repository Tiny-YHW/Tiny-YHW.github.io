---
layout: post
title: Allegro Timing Vision 等长长度实时可视化显示
categories: Allegro
description: 
date: 2023-06-15
---

16.6 QIR 2（HotFix6）引入，将等长组的线长关系，以可视化的颜色表现出来，十分有利于等长调整时使用

<iframe frameborder="0" src="https://v.qq.com/txp/iframe/player.html?vid=l0522cclm07" allowfullscreen="true" width="640" height="480"></iframe>