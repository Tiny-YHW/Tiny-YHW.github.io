---
layout: post
title: Allegro Auto-Interactive Phase Tune (AiPT) 自动差分对内等长
categories: Allegro
description: 
date: 2023-06-15
---

QIR 2（HotFix6）引入，用于自动调整一对或多对设好差分对内等长的差分线，使差分相位匹配

使用方法

- 从菜单Route \ Auto-interactive Phase Tune
- 从Option调整绕线选项
- 选择目标线


如下视频00:00-02:03部分为此功能的演示

<iframe frameborder="0" src="https://v.qq.com/txp/iframe/player.html?vid=u05222pbpop" allowfullscreen="true" width="640" height="480"></iframe>

另外一个国外的视频演示

<iframe frameborder="0" src="https://v.qq.com/txp/iframe/player.html?vid=d3149ddwc93" allowfullscreen="true" width="640" height="480"></iframe>