---
layout: post
title: 型号替代
categories: Components
date: 2023-06-06
---


[半导小芯](https://www.semiee.com/)

PIN TO PIN:pin to pin的意思是指两个IC的pin角功能完全一致，封装也完全一致,换句话说，如果你以前用的IC没有了，可以找一个pin to pin 的IC完全替代，而不用更改PCB的设计。